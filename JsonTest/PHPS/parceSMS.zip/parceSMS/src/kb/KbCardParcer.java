package kb;

import common.ParcerInterface;

public class KbCardParcer implements ParcerInterface {
	
	public KbCardBean getData(String str){
		KbCardBean bean = null;
		bean = new KbCardBean();
		
		bean.setCardName(this.getCardName(str));
		bean.setCardNum(this.getCardNum(str));
		bean.setGubun(this.getGubunValue(str));
		bean.setPrice(this.getPrice(str));
		bean.setTag(this.getTagValue(str));
		
		return bean;
	}

	@Override
	public String getCardName(String str) {
		// TODO Auto-generated method stub
		String[] cardName = null;
		String cardValue = "";
		
		cardName = str.split("\n");
		
		int firstNum = cardName[0].indexOf("(");
		
		
		cardValue = cardName[0].substring(0, firstNum);
		
		
		return cardValue;
	}
	
	
	public String getCardNum(String str){
		String cardNo = "";
		String[] cardName = null;
		String cardValue = "";
		
		cardName = str.split("\n");
		
		int firstNum = cardName[0].indexOf("(");
		
		cardNo = cardName[0].substring(firstNum);
		
		
		cardNo = cardNo.replace("(","");
		cardNo = cardNo.replace(")","");
		
		return cardNo;
	}
	
	

	@Override
	public String getGubunValue(String str) {
		// TODO Auto-generated method stub
		String gubun = "";
		
		String[]smsValue = null;
		smsValue = str.split("\n");
		
		gubun = smsValue[smsValue.length-1];
		
		int firstNum = gubun.indexOf("���");
		int secondNum = gubun.indexOf("���");
		int thirdNum = gubun.indexOf("�Һ�");
		
		if(firstNum!=-1){
			gubun = "���";
		}else if(secondNum!=-1){
			gubun = "���";
		}else if(thirdNum!= -1){
			gubun = "�Һ�";
		}
		
		
		return gubun;
	}

	@Override
	public String getPrice(String str) {
		// TODO Auto-generated method stub
		String price = "";
		String[] smsValue = null;
		
		smsValue = str.split("\n");
		
		price = smsValue[smsValue.length-2];
		
		price = price.replace("��","");
		price = price.replaceAll(",","");
		
		
		
		
		
		return price;
	}

	@Override
	public String getTagValue(String str) {
		// TODO Auto-generated method stub
		String tag = "";
		String[]smsValue = null;
		smsValue = str.split("\n");
		
		tag = smsValue[smsValue.length-1];
		
		tag = tag.replace("���","");
		tag = tag.replace("���","");
		tag = tag.replace("�Һ�","");
		
		return tag;
	}
	
	

}
