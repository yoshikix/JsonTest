package NH;

import common.ParcerInterface;

public class NhCardParcer  implements ParcerInterface{
	
	public NhCardBean getData(String str){
		NhCardBean bean = null;
		bean = new NhCardBean();
		
		bean.setCardName(this.getCardName(str));
		bean.setCardNum(this.getCardNum(str));
		bean.setGubun(this.getGubunValue(str));
		bean.setPrice(this.getPrice(str));
		bean.setTag(this.getTagValue(str));
		
		
		return bean;
	}

	@Override
	public String getCardName(String str) {
		// TODO Auto-generated method stub
		String cardName = "";
		String[] strs = str.split("\n");
		
		cardName = strs[3];
		
		int firstNum = cardName.indexOf("(");
		
		cardName = cardName.substring(0,firstNum);
		
		
		
		return cardName;
	}

	@Override
	public String getGubunValue(String str) {
		// TODO Auto-generated method stub
		String gubun = "";
		String strs[]  = null;
		
		strs = str.split("\n");
		gubun = strs[1];
		
		gubun = gubun.replace("[", "");
		gubun = gubun.replace("]", "");
		
		return gubun;
	}

	@Override
	public String getPrice(String str) {
		// TODO Auto-generated method stub
		String price = "";
		
		String[] strs = str.split("\n");
		
		price = strs[2];
		
		price = price.replace("��","");
		price = price.replaceAll(",","");
		
		
		return price;
	}

	@Override
	public String getTagValue(String str) {
		// TODO Auto-generated method stub
		String tag = "";
		String[]strs = str.split("\n");
		
		tag = strs[7];
		
		return tag;
	}

	@Override
	public String getCardNum(String str) {
		// TODO Auto-generated method stub
		String cardNum = "";
		String[] strs = str.split("\n");
		cardNum = strs[3];
		int firstNum = cardNum.indexOf("(");
		cardNum = cardNum.substring(firstNum);
		
		cardNum = cardNum.replace("(", "");
		cardNum = cardNum.replace(")", "");
		
		return cardNum;
	}
	

}
