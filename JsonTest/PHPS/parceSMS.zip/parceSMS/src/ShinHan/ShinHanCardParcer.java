package ShinHan;

import common.ParcerInterface;

public class ShinHanCardParcer implements ParcerInterface{
	
	
	public ShinHanCardBean getData(String str){
		ShinHanCardBean bean = null;
	
		bean = new ShinHanCardBean();
		
		bean.setCardName(this.getCardName(str));
		bean.setCardNum(this.getCardNum(str));
		bean.setGubun(this.getGubunValue(str));
		bean.setPrice(this.getPrice(str));
		bean.setTag(this.getTagValue(str));
		
		
		
		return bean;
		
	}

	@Override
	public String getCardName(String str) {
		// TODO Auto-generated method stub
		String cardName = "";
		String[] strs = str.split("\n");
		String[] chk = strs[0].split(" ");
		
		cardName = chk[0];
		
		cardName = cardName.replace("����", "");
		cardName = cardName.replace("���", "");
		cardName = cardName.replace("����", "");
		cardName = cardName.replace("�Һ�", "");
		
		return cardName.trim();
	}

	@Override
	public String getGubunValue(String str) {
		// TODO Auto-generated method stub
		String gubun = "";
		String[] strs = str.split("\n");
		
		gubun = strs[0];
		
		int a = gubun.indexOf("����");
		int b = gubun.indexOf("���");
		int c = gubun.indexOf("����");
		int d = gubun.indexOf("�Һ�");
	   
	   if(a!=-1){
		   gubun = "����";
	   }else if(b!=-1){
		   gubun="���";
	   }else if(c!=-1){
		   gubun="����";
	   }else if(d!=-1){
		   gubun="�Һ�";
	   }
		
		
		return gubun;
	}

	@Override
	public String getPrice(String str) {
		// TODO Auto-generated method stub
		String price = "";
		String[] strs = str.split("\n");
		
		price = strs[1];
		
		String[] prices  = price.split(" ");
		price = prices[1];
		
		price = price.replace("��" ,"");
		price = price.replace(",","");
		
		return price;
	}

	@Override
	public String getTagValue(String str) {
		// TODO Auto-generated method stub
		String tag = "";
		String[] strs = str.split("\n");
		tag = strs[2];
		
		return tag;
	}

	@Override
	public String getCardNum(String str) {
		// TODO Auto-generated method stub
		return "";
	}
	  

}
