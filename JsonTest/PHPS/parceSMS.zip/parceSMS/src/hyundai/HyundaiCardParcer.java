package hyundai;

import common.ParcerInterface;
import common.Util;


//ī��� ��������
public class HyundaiCardParcer implements ParcerInterface{
	
	
	//��ü ������ �������� 
	public HyunDaiCardBean getData(String str){
		HyunDaiCardBean bean = null;
		bean = new HyunDaiCardBean();
		
		bean.setCardName(this.getCardName(str));
		bean.setGubun(this.getGubunValue(str));
		bean.setPrice(this.getPrice(str));
		bean.setTag(this.getTagValue(str));
		
		
		return bean;
	}
	
	
	
	public  String getCardName(String str){
		String cardName="";
		
		int startPos  = str.indexOf("[");
		int endPos = str.indexOf("]");
		
		cardName = str.substring(startPos+1, endPos);
		
		//System.out.println(cardName);
		
		
		return cardName;
	}
	
	
	
	//���� : ����, ��� ��
	public String getGubunValue(String str){
		String gubun = "";
		
		int successPos = str.indexOf("-����");
		int cancelPos = str.indexOf("-���");
		
		
		if(successPos !=-1){
			gubun="����";			
		}
		if(cancelPos!=-1){
			gubun="���";
		}
		
		
		return gubun;
		
	}
	
	
	
	public String getPrice(String str){
		String price ="";
		
		int startPos = str.indexOf("��");
		int endPos = str.indexOf("��");
		
		price = str.substring(startPos+1 , endPos);
		price = price.replaceAll("\n", "");
		price = price.replaceAll(",","");
		price = price.trim();
		
		
		return price;
		
	}
	
	
	
	public String getTagValue(String str){
		Util util = new Util();
		String tagValue = "";
		
		int startPos = str.indexOf(")");
		int endPos = str.length();
		
		
		int chkPos = str.indexOf("����");
		
		if(chkPos==-1){
			tagValue = str.substring(startPos+1);
		}else{
			tagValue = str.substring(startPos+1 , chkPos);
		}
		
		tagValue = util.getData(tagValue);
		
		
		return tagValue;
	}

	
	
	@Override
	public String getCardNum(String str) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
