package common;

public class Util {

	public  String getData(String str){
		String data = "";
		
		data = str.replaceAll("\n","");
		data = data.trim();
		
		return data;
	
	}

}
